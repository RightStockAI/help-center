---
sidebar_position: 1
---

# Getting Started

## Creating Your Account

### Step 1: Sign Up

1. Visit [RightStockAI Sign Up](https://www.rightstockai.com/signup)
2. Enter your email address
3. Create a strong password
4. Verify your email address
5. Complete your profile setup

### Step 2: Subscription Plans

Choose the plan that fits your needs:

#### **Free Plan**
- Basic AI stock analysis
- Stock details and market overview
- AI news insights
- Limited portfolio tracking
- Standard support

#### **Pro Plan**
- Advanced AI analysis (56+ metrics)
- Traditional analysis (100+ metrics)
- Full portfolio management
- Advanced portfolio optimization
- Watchlist with alerts
- Priority support
- All future features

### Step 3: First Login

After signing up:
1. Navigate to [Dashboard](https://www.rightstockai.com/dashboard)
2. Complete the interactive product tour
3. Set up your preferences
4. Start analyzing stocks!

## Browser Requirements

RightStockAI works best on modern browsers:
- Chrome 102 or higher
- Firefox 102 or higher
- Safari 15.4 or higher
- Edge 102 or higher

## Mobile Access

Access RightStockAI on any device:
- Responsive design for tablets
- Mobile-optimized interface
- Touch-friendly controls
- Full feature access on mobile

## System Requirements

- Stable internet connection (minimum 2 Mbps recommended)
- JavaScript enabled
- Cookies enabled for authentication
- Screen resolution: 1024x768 or higher recommended

## Next Steps

- [Explore the Dashboard](./dashboard)
- [Understanding the Interface](./navigation)
- [Your First Stock Analysis](../features/stock-analysis)