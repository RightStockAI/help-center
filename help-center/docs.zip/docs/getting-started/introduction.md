***
sidebar_position: 1
title: Introduction to RightStockAI
description: Learn the basics of using RightStockAI platform
***

# Introduction to RightStockAI

Welcome! This guide will help you understand RightStockAI and get you up and running quickly.

## What Makes RightStockAI Different?

### Dual Analysis Approach

Unlike traditional platforms that offer only technical analysis, RightStockAI provides **two complementary methods**:

1. **AI-Powered Analysis**
   - Uses deep learning to identify complex patterns
   - Provides price predictions with confidence scores
   - Analyzes thousands of data points simultaneously
   - Learns from historical market behavior

2. **Traditional Technical Analysis**
   - Classic indicators used by professional traders
   - Time-tested methods (RSI, MACD, Moving Averages)
   - Support and resistance level identification
   - Chart patterns and trend analysis

:::tip Why Both Methods?
When AI and traditional analysis **agree**, you have stronger signals. When they **differ**, it's a signal to investigate further or proceed with caution.
:::

## Core Features Overview

### 1. Stock Search & Analysis
- Search across NSE and BSE stocks
- View real-time and historical data
- Get AI predictions for multiple timeframes
- See traditional technical indicators
- Compare AI vs traditional analysis side-by-side

### 2. Portfolio Tracking
- Create and manage multiple portfolios
- Add your stock holdings with purchase details
- Track real-time portfolio value
- View performance metrics
- Analyze sector allocation
- Calculate returns and P&L

### 3. AI Portfolio Analysis
- Get AI-powered portfolio insights
- Receive risk assessment scores
- See diversification recommendations
- Get rebalancing suggestions
- View predicted portfolio performance

### 4. Watchlist Management
- Create custom watchlists by strategy or sector
- Monitor stocks before investing
- Set price alerts
- Quick access to analysis from watchlist

### 5. Market Overview
- Live NIFTY 50 and Sensex data
- Sector performance tracking
- Top gainers and losers
- Market sentiment indicators

## Platform Philosophy

### Analysis, Not Advice

RightStockAI is an **analysis platform**, not a financial advisor. We provide:

✅ **Data and Insights** - AI predictions, technical indicators, historical data  
✅ **Tools** - Portfolio tracking, watchlists, alerts  
✅ **Education** - Help you understand analysis methods  

❌ **Not Financial Advice** - We don't tell you what to buy or sell  
❌ **Not Guaranteed** - All predictions are probabilities, not certainties  
❌ **Not a Substitute** - Always do your own research  

### User Empowerment

Our goal is to **empower you** with:
- Professional-grade analysis tools
- AI insights previously available only to institutions
- Clear, understandable information
- Education about markets and AI

## Who Is RightStockAI For?

### Perfect For:
- **Individual Investors** - Track your portfolio and get AI insights
- **Active Traders** - Use AI + technical analysis for better decisions
- **Learning Investors** - Understand how AI and technical analysis work
- **Research-Focused Users** - Analyze stocks before investing

### Also Useful For:
- Financial advisors supplementing their research
- Students learning about markets and AI
- Anyone interested in Indian stock markets

## What You'll Need

### Required:
- ✅ A RightStockAI account (free to create)
- ✅ Basic understanding of stocks (we'll help you learn!)
- ✅ Internet connection

### Optional But Helpful:
- Understanding of technical indicators (we explain them!)
- Investment goals and risk tolerance defined
- Existing portfolio to track

## Platform Access

### Web Application
Access RightStockAI at: **[https://rightstockai.com](https://rightstockai.com)**

- Works on all modern browsers (Chrome, Firefox, Safari, Edge)
- Responsive design works on desktop, tablet, and mobile
- No installation required
- Always up-to-date

### Account Types

#### Free Tier
- Limited daily analyses
- Basic portfolio tracking
- Core features available

#### Premium Plans
- Unlimited analyses
- Advanced AI features
- Priority support
- Extended historical data

[View Pricing →](https://rightstockai.com/pricing)

## Getting Started Checklist

Follow these steps to get the most out of RightStockAI:

- [ ] Create your account
- [ ] Complete your profile setup
- [ ] Take a tour of the dashboard
- [ ] [Search and analyze your first stock](/getting-started/first-analysis)
- [ ] [Create a portfolio](/portfolio/creating-portfolio) with your holdings
- [ ] Create a watchlist for stocks you're interested in
- [ ] Set up price alerts
- [ ] Explore AI portfolio insights

## Understanding the Dashboard

When you log in, you'll see:

### Top Navigation
- **Search Bar** - Find stocks quickly by name or symbol
- **Dashboard** - Your personalized overview
- **Analysis** - Access stock analysis tools
- **Portfolio** - Manage your portfolios
- **Watchlist** - View your watchlists
- **Markets** - Market overview and trends

### Dashboard Widgets
- **Market Overview** - NIFTY 50, Sensex, sector performance
- **Your Portfolios** - Quick view of portfolio performance
- **Watchlists** - Stocks you're monitoring
- **Recent Analyses** - Your analysis history
- **Alerts** - Price alerts and notifications

### Quick Actions
- 🔍 **Search Stock** - Analyze any stock instantly
- ➕ **Add to Portfolio** - Record a stock purchase
- 👁️ **Add to Watchlist** - Monitor a stock
- 🔔 **Set Alert** - Get notified at target prices

## Data Sources

### Our Data Comes From:
- **NSE (National Stock Exchange)** - Real-time and historical data
- **BSE (Bombay Stock Exchange)** - Real-time and historical data
- **Official Market Sources** - Reliable, professional-grade data

### Data Update Frequency:
- **During Market Hours (9:15 AM - 3:30 PM IST)** - Real-time updates
- **After Market Close** - End-of-day updates
- **Historical Data** - Updated daily

## Support & Resources

### Need Help?
- 📚 **This Help Center** - Comprehensive documentation
- 💬 **Contact Support** - support@rightstockai.com
- 🐛 **Report Issues** - Found a bug? Let us know
- 💡 **Feature Requests** - Suggest improvements

### Community
- GitHub - [View our progress](https://github.com/dhananjaym182/RightStockAI)
- Updates - Check our platform for latest features

## Privacy & Security

Your data security is our priority:

- 🔒 **Encrypted Data** - All data transmitted securely (HTTPS)
- 🛡️ **Privacy First** - We don't sell your data
- 🔐 **Secure Authentication** - Password encryption and security
- 📊 **Anonymous Analytics** - Usage data is anonymized

[Read Privacy Policy →](https://rightstockai.com/privacy-policy)

## Next Steps

Ready to dive in? Choose your path:

1. **[Platform Navigation](/getting-started/navigation)** - Learn how to navigate RightStockAI
2. **[Your First Analysis](/getting-started/first-analysis)** - Analyze a stock step-by-step
3. **[Account Setup](/getting-started/account-setup)** - Customize your experience

***

**Questions?** [Check our FAQ](/faq/account) or [contact support](mailto:support@rightstockai.com)