***
sidebar_position: 3
title: Portfolios and Watchlists FAQ
description: Questions about managing portfolios and watchlists
***

# Portfolios and Watchlists FAQ

Common questions about portfolio management and watchlist functionality.

## Portfolio Management

### How many portfolios can I create?
- **Free**: 1 portfolio
- **Premium**: Unlimited portfolios
- **Sub-portfolios**: Unlimited within main portfolios

### What portfolio types are supported?
- **Personal** - Individual investments
- **Joint** - Shared with others
- **Retirement** - Tax-advantaged accounts
- **Trust** - Held in trust
- **Custom** - User-defined types

### How do I add holdings?
1. **Manual entry** - Input transaction details
2. **Bulk import** - CSV upload
3. **Broker sync** - Auto-import from connected brokers
4. **Copy from watchlist** - Transfer from watchlist

### What transaction types are supported?
- **Buy** - Purchase shares
- **Sell** - Sell shares
- **Dividend** - Cash dividend received
- **Split** - Stock split adjustment
- **Bonus** - Bonus shares received
- **Rights** - Rights issue participation

## Performance Tracking

### What metrics are calculated?
- **Total return** - Overall portfolio performance
- **Annualized return** - Time-weighted annual return
- **Benchmark comparison** - Vs NIFTY 50, Sensex
- **Risk metrics** - Volatility, Sharpe ratio

### How is cost basis calculated?
- **FIFO** - First in, first out
- **Average cost** - Blended purchase price
- **Specific lots** - Track individual purchases
- **Tax optimization** - Minimize tax impact

### What reports are available?
- **Performance summary** - Key metrics overview
- **Holding analysis** - Individual stock performance
- **Sector breakdown** - Industry allocation
- **Tax reports** - Capital gains/losses

## Watchlist Management

### How many watchlists can I create?
- **Free**: 3 watchlists
- **Premium**: Unlimited watchlists
- **Stocks per list**: Unlimited

### What watchlist features are available?
- **Stock alerts** - Price and news notifications
- **Performance tracking** - Watchlist return calculation
- **Analysis integration** - Quick stock analysis
- **Portfolio conversion** - Move to portfolio

### How do I set up alerts?
1. **Select stock** in watchlist
2. **Click alerts** button
3. **Choose alert type** - Price, volume, news
4. **Set parameters** - Target values, conditions
5. **Select notification** - Email, push, SMS

### Can I share watchlists?
- **Private** - Personal use only
- **Public links** - Share read-only access
- **Team sharing** - Collaborate with others
- **Export** - CSV/PDF export

## Data Import/Export

### What import formats are supported?
- **CSV files** - Standard spreadsheet format
- **Excel files** - .xlsx format support
- **Broker statements** - PDF parsing
- **API integration** - Direct broker connection

### What data can I export?
- **Portfolio holdings** - Complete position list
- **Transaction history** - All buy/sell records
- **Performance reports** - Generated analytics
- **Tax documents** - Capital gains reports

### How do I connect my broker?
1. **Select broker** from supported list
2. **Authorize connection** - Secure API access
3. **Map accounts** - Link trading accounts
4. **Set sync frequency** - Daily/weekly updates

## Rebalancing

### What rebalancing methods are available?
- **Percentage-based** - Maintain target allocations
- **Threshold-based** - Rebalance when deviation exceeds limit
- **Calendar-based** - Regular schedule (quarterly)
- **Tax-loss harvesting** - Rebalance with tax benefits

### How does tax-loss harvesting work?
1. **Identify losses** - Stocks below purchase price
2. **Sell losers** - Realize capital losses
3. **Buy similar** - Purchase correlated securities
4. **Offset gains** - Reduce taxable gains
5. **Wash sale rules** - Avoid identical security repurchase

### What are rebalancing costs?
- **Transaction fees** - Brokerage commissions
- **Bid-ask spreads** - Market impact costs
- **Tax implications** - Capital gains taxes
- **Opportunity costs** - Foregone returns

## Risk Management

### What risk metrics are provided?
- **Portfolio volatility** - Standard deviation
- **Value at Risk (VaR)** - Potential loss estimate
- **Sharpe ratio** - Risk-adjusted returns
- **Maximum drawdown** - Worst peak-to-trough decline

### How is diversification measured?
- **Asset allocation** - Stock/bond/cash breakdown
- **Sector weights** - Industry concentration
- **Geographic exposure** - Country diversification
- **Correlation matrix** - Holding relationships

### What stress testing is available?
- **Historical scenarios** - Past crisis periods
- **Hypothetical scenarios** - Custom stress tests
- **Monte Carlo simulation** - Probability analysis
- **Sensitivity analysis** - Impact of variable changes

## Tax Considerations

### How are capital gains calculated?
- **Short-term** - Held ≤ 1 year (higher tax rate)
- **Long-term** - Held > 1 year (lower tax rate)
- **Indexation** - Inflation adjustment for long-term
- **Foreign stocks** - Additional tax considerations

### What tax reports are generated?
- **Capital gains/losses** - Realized transactions
- **Dividend income** - Cash dividend tracking
- **Holding periods** - Short-term vs long-term classification
- **Tax optimization** - Suggestions for tax efficiency

### How do I handle international investments?
- **Currency conversion** - Automatic forex calculations
- **Withholding taxes** - Foreign tax credits
- **Double taxation** - Tax treaty benefits
- **Reporting requirements** - Regulatory compliance

## Mobile and Accessibility

### Is mobile access available?
- **Responsive web** - Works on all mobile browsers
- **Progressive web app** - Install on home screen
- **Mobile optimization** - Touch-friendly interface
- **Offline viewing** - Limited offline functionality

### What accessibility features exist?
- **Screen reader support** - Compatible with assistive technology
- **Keyboard navigation** - Full keyboard control
- **High contrast mode** - Better visibility options
- **Font size adjustment** - Customizable text size

## Troubleshooting

### Portfolio not updating?
- **Refresh data** - Manual refresh button
- **Check connections** - Broker API status
- **Verify holdings** - Confirm transaction accuracy
- **Contact support** - For persistent issues

### Watchlist alerts not working?
- **Check settings** - Verify alert configuration
- **Email preferences** - Confirm notification settings
- **Spam folder** - Check email filters
- **Browser permissions** - Allow notifications

### Import failing?
- **File format** - Ensure correct CSV structure
- **Data validation** - Check for errors in data
- **Column mapping** - Verify field assignments
- **File size limits** - Check upload restrictions