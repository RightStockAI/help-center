***
sidebar_position: 5
title: Technical Support FAQ
description: Technical issues, troubleshooting, and platform support
***

# Technical Support FAQ

Get help with technical issues, platform problems, and troubleshooting.

## Platform Access Issues

### Can't log in to account?
**Check these solutions:**
- Verify email and password are correct
- Reset password if forgotten
- Check email verification status
- Clear browser cache and cookies
- Try different browser or incognito mode
- Check internet connection

### Platform not loading?
**Try these fixes:**
- Refresh the page (Ctrl+F5)
- Clear browser cache
- Disable browser extensions temporarily
- Try different browser
- Check network connectivity
- Contact support if persistent

### Mobile app issues?
**Common solutions:**
- Update to latest app version
- Clear app cache and data
- Reinstall the app
- Check device compatibility
- Verify internet connection
- Enable app permissions

## Data and Analysis Problems

### Stock data not updating?
**Possible causes and fixes:**
- Check market hours (9:15 AM - 3:30 PM IST)
- Refresh data manually
- Verify stock symbol correctness
- Check data source status
- Wait for end-of-day updates

### Analysis not working?
**Troubleshooting steps:**
- Check internet connection
- Refresh the analysis page
- Try different stock or time period
- Clear browser cache
- Contact support with error details

### Charts not displaying?
**Fix chart issues:**
- Enable JavaScript in browser
- Update browser to latest version
- Disable ad blockers temporarily
- Try different browser
- Check graphics card drivers

## Portfolio Management Issues

### Holdings not updating?
**Resolution steps:**
- Manually refresh portfolio
- Check transaction entry accuracy
- Verify broker connection status
- Re-enter incorrect transactions
- Contact support for sync issues

### Performance calculations wrong?
**Verify calculations:**
- Check transaction dates and prices
- Confirm cost basis method (FIFO/LIFO)
- Verify dividend inclusions
- Compare with manual calculations
- Report discrepancies to support

### Import/export failing?
**File issues:**
- Check CSV format and columns
- Verify file size limits
- Ensure correct encoding (UTF-8)
- Remove special characters
- Try smaller batches

## Alert and Notification Problems

### Not receiving alerts?
**Check settings:**
- Verify email address is correct
- Check spam/junk folders
- Confirm alert preferences
- Test with different alert types
- Enable browser notifications

### Alerts triggering incorrectly?
**Adjust settings:**
- Review alert thresholds
- Check time zones
- Verify stock symbols
- Update trigger conditions
- Contact support for complex issues

## Account and Billing Issues

### Billing questions?
**Get help:**
- Check billing history in account
- Verify payment method status
- Contact support for disputes
- Review subscription details
- Check for pending charges

### Account access problems?
**Security issues:**
- Reset password securely
- Check for suspicious activity
- Enable two-factor authentication
- Review login history
- Contact support immediately

## Performance and Speed Issues

### Platform running slow?
**Optimization tips:**
- Close unused browser tabs
- Clear browser cache regularly
- Update browser and system
- Check internet speed
- Use wired connection if possible
- Disable unnecessary extensions

### Large portfolios slow?
**Performance solutions:**
- Use summary views instead of detailed
- Limit historical data display
- Archive old transactions
- Use filters to reduce data load
- Contact support for optimization

## Browser Compatibility

### Supported browsers?
**Recommended:**
- Chrome (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Edge (latest 2 versions)

### Browser settings?
**Required settings:**
- JavaScript enabled
- Cookies enabled
- Pop-ups allowed for alerts
- HTTPS enabled
- WebGL enabled for charts

## Mobile and App Issues

### App crashing?
**Fix crashes:**
- Update to latest version
- Restart device
- Clear app cache
- Reinstall if necessary
- Check device storage space
- Report crash logs to support

### Sync not working?
**Sync issues:**
- Check internet connection
- Force sync manually
- Verify account credentials
- Check server status
- Reconnect account if needed

## Security and Privacy

### Security concerns?
**Protection measures:**
- Use strong, unique passwords
- Enable two-factor authentication
- Monitor account activity
- Report suspicious activity
- Keep software updated

### Data privacy questions?
**Privacy assurance:**
- Data encrypted in transit and at rest
- No data sold to third parties
- Compliance with privacy regulations
- User data control options
- Transparent data usage policies

## Advanced Troubleshooting

### API connection issues?
**API troubleshooting:**
- Verify API keys are correct
- Check rate limits
- Confirm endpoint URLs
- Review error messages
- Contact developer support

### Custom integrations failing?
**Integration help:**
- Check documentation
- Verify authentication
- Test with sample data
- Review error logs
- Contact integration support

## Getting Additional Help

### Support channels
- **Email**: support@rightstockai.com
- **Live chat**: Available during business hours
- **Help center**: Search existing solutions
- **Community forums**: User-to-user support
- **Video tutorials**: Visual troubleshooting

### What to include in support requests
- **Detailed description** of the problem
- **Steps to reproduce** the issue
- **Screenshots** of error messages
- **Browser/device information**
- **Account details** (without sensitive info)
- **Timeline** of when issue started

### Response times
- **Critical issues**: Within 1 hour
- **Urgent issues**: Within 4 hours
- **Standard issues**: Within 24 hours
- **Feature requests**: Within 48 hours
- **General inquiries**: Within 1 week

## Prevention Best Practices

### Regular maintenance
- Keep browser updated
- Clear cache regularly
- Monitor account activity
- Backup important data
- Update contact information

### Security habits
- Use strong passwords
- Enable 2FA everywhere
- Be cautious with links
- Monitor login activity
- Report issues promptly

### Performance optimization
- Close unused tabs
- Use latest browser versions
- Clear downloads regularly
- Monitor storage usage
- Regular system updates