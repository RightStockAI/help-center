---
sidebar_position: 1
---

# Account and Platform FAQ

Common questions and answers about RightStockAI accounts, registration, and platform access.

## General Questions

### What is RightStockAI?

RightStockAI is an AI-powered stock analysis platform focused on Indian stock markets (NSE, BSE). We provide comprehensive analysis using both traditional financial methodologies and advanced machine learning algorithms to help investors make informed decisions.

### Which markets do you cover?

We cover:
- NSE (National Stock Exchange)
- BSE (Bombay Stock Exchange)
- NIFTY 50 stocks
- Sensex stocks
- Mid-cap and small-cap stocks
- All major Indian equity securities

### Is RightStockAI free to use?

Yes, we offer a free plan with basic features. For advanced analysis, portfolio management, and premium features, upgrade to our Pro plan.

[View Plans](../subscription/plans)

---

## Account & Registration

### How do I create an account?

1. Visit [Sign Up](https://www.rightstockai.com/signup)
2. Enter your email and password
3. Verify your email
4. Complete profile setup
5. Start analyzing stocks!

### I forgot my password. How do I reset it?

1. Go to [Sign In](https://www.rightstockai.com/signin)
2. Click "Forgot Password"
3. Enter your registered email
4. Check email for reset link
5. Create new password

### Can I change my email address?

Yes, go to [My Profile](https://www.rightstockai.com/user/profile) and update your email. You'll need to verify the new email address.

### How do I delete my account?

Contact support at support@rightstockai.com with your deletion request. We'll process it within 48 hours.

### What are the account types?

- **Free Account**: Basic features, limited daily requests
- **Pro Account**: Higher limits, advanced features, priority support
- **Premium Account**: Unlimited usage, team access, enterprise features

### How do I upgrade my account?

1. Go to [My Subscription](https://www.rightstockai.com/subscription)
2. Select desired plan
3. Enter payment information
4. Confirm upgrade
5. Enjoy enhanced features immediately

### Can I downgrade my account?

Yes, you can downgrade at any time:
1. Go to [My Subscription](https://www.rightstockai.com/subscription)
2. Select lower plan
3. Change takes effect at next billing cycle
4. Keep current features until then

---

## Subscription & Billing

### How much does Pro cost?

View current pricing at [Subscription Plans](https://www.rightstockai.com/subscription)

We offer:
- Monthly billing: ₹399/month
- Annual billing: ₹3,830/year (save 20%)
- Premium plans also available

### Is there a free trial?

Yes! We offer a 14-day free trial of Pro features. No credit card required to start.

[Start Free Trial](https://www.rightstockai.com/subscription)

### What payment methods do you accept?

- Credit/Debit Cards (Visa, Mastercard, RuPay, Amex)
- UPI (Google Pay, PhonePe, Paytm, BHIM)
- Net Banking (All major Indian banks)
- Digital Wallets (Paytm Wallet, PhonePe Wallet)

### Can I cancel anytime?

Yes, cancel anytime from [My Subscription](https://www.rightstockai.com/subscription). You'll retain access until the end of your billing period.

### Do you offer refunds?

Yes, we offer refunds within 7 days of purchase if you're not satisfied. Contact billing@rightstockai.com.

### Will prices increase after I subscribe?

Your price is locked in as long as you maintain continuous subscription. New subscribers may see different pricing.

### What's included in each plan?

**Free Plan:**
- Basic AI Stock Analysis (5 requests/day)
- AI News Analysis (3 requests/day)
- Traditional Stock Analysis (10 requests/day)
- Basic Charts (10 requests/day)
- Data Export (5 requests/day)
- Community Support

**Pro Plan:**
- Advanced AI Stock Analysis (50 requests/day)
- AI News Analysis (50 requests/day)
- Traditional Stock Analysis (200 requests/day)
- Advanced AI Portfolio Analysis (20 requests/day)
- Premium Charts (200 requests/day)
- Data Export (50 requests/day)
- Priority Email Support (6-12 hour response)
- Custom Alerts & Notifications

**Premium Plan:**
- Unlimited everything
- Full API Access
- Dedicated Account Manager
- Phone & Priority Support (2-4 hour response)
- Custom Integrations
- White-label Solutions
- Up to 5 users

---

## Platform Access

### What devices are supported?

- **Desktop**: Chrome 102+, Firefox 102+, Safari 15.4+, Edge 102+
- **Mobile**: iOS Safari, Android Chrome
- **Tablets**: iPad, Android tablets
- **Responsive design** works on all screen sizes

### Is the platform secure?

Yes, we use industry-standard security:
- 256-bit SSL encryption for all data transmission
- Secure authentication with password hashing
- Regular security audits
- Data backup and redundancy
- PCI DSS compliant payment processing

### Can I export my data?

Yes, you can export:
- Portfolio data (CSV, PDF)
- Analysis history (PDF reports)
- Transaction records (CSV)
- Settings backup (JSON)

Go to Profile > Data Export

### How is my data protected?

We implement:
- 256-bit SSL encryption
- Secure authentication (Better-auth)
- Encrypted database storage
- Regular security audits
- Secure payment processing

### Do you share my data?

No, we never sell or share your personal data. View our [Privacy Policy](https://www.rightstockai.com/privacy) for details.

### How long do you retain data?

- **Active accounts**: Data retained indefinitely
- **Canceled subscriptions**: Data retained 90 days
- **Deleted accounts**: Data deleted within 30 days

---

## Technical Issues

### The website is loading slowly

Try these steps:
1. Clear browser cache and cookies
2. Try a different browser
3. Check your internet connection
4. Disable browser extensions
5. Try incognito/private mode

Still slow? Contact support@rightstockai.com

### Charts are not loading

**Solutions:**
1. Refresh page
2. Enable JavaScript
3. Allow third-party cookies
4. Update your browser
5. Try different browser
6. Clear cache

### I can't log in

**Common fixes:**
1. Verify correct email/password
2. Check CAPS LOCK
3. Clear browser cache
4. Try password reset
5. Disable browser extensions
6. Try different browser

### Portfolio upload failed

**Troubleshooting:**
1. Check file format (CSV/Excel)
2. Verify column headers match sample
3. Remove special characters
4. Ensure file size < 5MB
5. Try sample format first
6. Contact support with file

### Analysis is not generating

**Possible causes:**
1. Stock symbol incorrect
2. Market closed (check time)
3. Data not available for stock
4. Server maintenance
5. Subscription expired

Refresh page and try again. If issue persists, contact support.

---

## Features & Usage

### How many stocks can I analyze?

**Free Plan:**
- AI Stock Analysis: 5 requests/day
- Traditional Analysis: 10 requests/day
- Charts: 10 requests/day
- Data Export: 5 requests/day

**Pro Plan:**
- AI Stock Analysis: 50 requests/day
- Traditional Analysis: 200 requests/day
- Charts: 200 requests/day
- Data Export: 50 requests/day

**Premium Plan:**
- Unlimited everything

### What counts as a "request"?

**AI Stock Analysis Request:**
- Running AI analysis on one stock = 1 request
- Same stock analyzed multiple times = multiple requests

**Traditional Analysis Request:**
- Running traditional analysis on one stock = 1 request
- Each new analysis = 1 request

**Chart Request:**
- Opening/loading a chart = 1 request
- Viewing same chart (cached) = no additional request

**Data Export Request:**
- Exporting one analysis to PDF/Excel = 1 request
- Each export = 1 request

### When do limits reset?

**Reset Time:** Every day at 12:00 AM IST

**Example:**
- Used 5 AI analyses by 11:00 PM today
- At 12:00 AM, you get 5 new requests
- Previous day's usage doesn't carry over

### Can I save analyses?

Yes! Saved analyses don't count toward limits when reviewing. You can:
- Save analysis results to your account
- Access saved analyses anytime
- Export saved analyses
- Compare different analyses

### Can I share analyses?

- **Private by default** - Only you can see
- **Share links** - Generate public links (Pro feature)
- **Export reports** - PDF/CSV exports
- **Collaboration** - Team features (Premium)

---

## Mobile & Accessibility

### Is there a mobile app?

Currently, we offer a mobile-responsive website that works on all devices. Native apps for iOS and Android are coming soon!

### Does it work on tablets?

Yes, our platform is fully responsive and works great on tablets.

### Which browsers are supported?

Supported browsers:
- Chrome 102+
- Firefox 102+
- Safari 15.4+
- Edge 102+

### Is the platform accessible?

We strive for accessibility compliance:
- Keyboard navigation support
- Screen reader compatible
- High contrast mode
- Text size adjustments
- WCAG 2.1 guidelines

---

## Getting Help

### How do I contact support?

**Multiple ways to reach us:**

📧 **Email:** support@rightstockai.com
- Response time: 24-48 hours (Free)
- Response time: 6-12 hours (Pro)

💬 **Live Chat:** Available on website
- Available: 9 AM - 6 PM IST
- Pro users get priority

📖 **Documentation:** This knowledge base
- Comprehensive guides
- Video tutorials
- Step-by-step instructions

🎯 **Product Tour:** In-app guided tour
- Interactive walkthrough
- Feature highlights
- Best practices

### What's the support response time?

- **Free users**: 24-48 hours
- **Pro users**: 6-12 hours
- **Premium users**: 2-4 hours

### Can I schedule a demo?

Yes! Enterprise customers can schedule personalized demos. Email enterprise@rightstockai.com

---

## Still Have Questions?

Can't find your answer? We're here to help!

- 📧 Email: support@rightstockai.com
- 💬 [Live Chat](https://www.rightstockai.com/support)
- 📖 [Browse Documentation](../intro)
- 🎯 [Start Product Tour](https://www.rightstockai.com/dashboard)