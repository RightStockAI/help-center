***
sidebar_position: 2
title: Managing Your Holdings
description: How to add, edit, and track your portfolio holdings
***

# Managing Your Holdings

Effective portfolio management requires accurate tracking of all your holdings. This guide covers adding, editing, and maintaining your investment positions in RightStockAI.

## Adding New Holdings

### Individual Stock Purchase

#### Step-by-Step Process
1. Navigate to your portfolio
2. Click **"Add Holding"**
3. Search for the stock by name or symbol
4. Select the correct stock from results
5. Choose transaction type: **Buy**
6. Enter purchase details

#### Required Information
- **Date** - When you purchased the stock
- **Quantity** - Number of shares bought
- **Price** - Purchase price per share
- **Brokerage** - Transaction fees paid
- **Exchange Rate** - If purchased in different currency

#### Optional Information
- **Notes** - Reason for purchase or strategy
- **Tags** - Categorize the holding (growth, value, dividend)
- **Target Price** - Price you're aiming for
- **Stop Loss** - Price to sell if it drops

### Bulk Additions

#### CSV Import
1. Prepare CSV file with columns:
   ```
   Symbol,Date,Quantity,Price,Brokerage,Notes
   RELIANCE.NS,2024-01-15,100,2500,50,Growth stock
   TCS.NS,2024-01-20,50,3200,25,IT sector
   ```
2. Click **"Import Holdings"**
3. Upload your CSV file
4. Map columns to RightStockAI fields
5. Review imported data
6. Confirm import

#### Broker Integration
- **Supported Brokers** - Zerodha, Upstox, Angel One, etc.
- **API Setup** - Secure connection to broker
- **Auto-sync** - Automatic portfolio updates
- **Transaction History** - Import past trades

## Editing Holdings

### Modifying Purchase Details

#### Correcting Information
1. Click on the holding in your portfolio
2. Select **"Edit Transaction"**
3. Update incorrect information
4. Save changes

#### Common Edits
- **Price Corrections** - Fix wrong purchase price
- **Date Changes** - Correct transaction date
- **Quantity Adjustments** - Fix share count
- **Fee Updates** - Add missing brokerage

### Adding Additional Purchases

#### Same Stock, Different Lots
1. Click **"Add Transaction"** on existing holding
2. Select **"Buy"** transaction type
3. Enter new purchase details
4. System calculates new average cost

#### Lot Tracking Benefits
- **Tax Optimization** - Track individual purchase lots
- **Cost Basis** - Accurate FIFO/LIFO calculations
- **Performance Analysis** - See which lots are profitable

## Recording Sales

### Selling Holdings

#### Complete Sale
1. Click on holding
2. Select **"Add Transaction"**
3. Choose **"Sell"** type
4. Enter sale details:
   - Sale date
   - Quantity sold
   - Sale price
   - Brokerage fees

#### Partial Sale
- **Specify Quantity** - Sell portion of holding
- **Lot Selection** - Choose which purchase lots to sell
- **Tax Implications** - Track short-term vs long-term gains

### Sale Information
- **Realized Gains/Losses** - Automatic calculation
- **Holding Period** - Days/months held
- **Tax Treatment** - Short-term/long-term classification
- **Cost Basis** - Accurate cost for tax purposes

## Tracking Corporate Actions

### Stock Splits

#### Recording Splits
1. System detects split announcements
2. Automatically adjusts share count
3. Updates cost basis proportionally
4. Maintains accurate portfolio value

#### Manual Split Entry
1. Click **"Add Transaction"**
2. Select **"Stock Split"**
3. Enter split ratio (e.g., 2:1)
4. System adjusts holdings

### Bonus Shares

#### Bonus Issue Recording
1. Click **"Add Transaction"**
2. Select **"Bonus Shares"**
3. Enter bonus ratio (e.g., 1:1)
4. System adds bonus shares at zero cost

### Dividends

#### Dividend Tracking
- **Automatic Detection** - System monitors dividend announcements
- **Portfolio Impact** - Adds dividend income to returns
- **Tax Treatment** - Tracks dividend taxation
- **Reinvestment** - Option to reinvest dividends

## Managing Multiple Portfolios

### Portfolio Organization

#### Creating Sub-portfolios
1. Within main portfolio, click **"Create Sub-portfolio"**
2. Name the sub-portfolio (e.g., "Growth Stocks")
3. Set target allocation percentage
4. Move holdings between portfolios

#### Benefits
- **Better Organization** - Group related investments
- **Performance Tracking** - Sub-portfolio level analytics
- **Rebalancing** - Maintain target allocations
- **Tax Planning** - Optimize for different goals

### Transferring Holdings

#### Between Portfolios
1. Select holding to transfer
2. Click **"Transfer"**
3. Choose destination portfolio
4. Specify quantity to transfer
5. System handles cost basis appropriately

## Cost Basis Tracking

### Cost Basis Methods

#### FIFO (First In, First Out)
- Sells oldest shares first
- Common for tax purposes
- Matches typical investment behavior

#### LIFO (Last In, First Out)
- Sells newest shares first
- May provide tax advantages
- Less common for long-term investors

#### Average Cost
- Blends all purchase prices
- Simplifies calculations
- Used by some mutual funds

### Tax Optimization

#### Tax-Loss Harvesting
- Identify losing positions
- Sell to offset gains
- Repurchase similar (but not identical) securities
- Follow wash sale rules

#### Long-term vs Short-term
- **Long-term** - Held > 1 year (preferential tax rates)
- **Short-term** - Held ≤ 1 year (higher tax rates)
- **Planning** - Time sales for optimal tax treatment

## Performance Monitoring

### Holding-Level Analytics

#### Individual Stock Performance
- **Unrealized P&L** - Current profit/loss
- **Total Return** - Including dividends
- **Holding Period** - Time invested
- **Benchmark Comparison** - Vs NIFTY 50

#### Risk Metrics
- **Volatility** - Price fluctuation
- **Beta** - Market sensitivity
- **Sharpe Ratio** - Risk-adjusted returns
- **Maximum Drawdown** - Worst loss period

### Portfolio Impact

#### Contribution Analysis
- **Return Contribution** - How much each holding adds
- **Risk Contribution** - Volatility added by holding
- **Sector Impact** - Effect on sector allocation
- **Diversification Effect** - Correlation with portfolio

## Alerts and Notifications

### Price Alerts
- **Target Price** - Alert when stock reaches target
- **Stop Loss** - Alert when stock hits stop price
- **Percentage Change** - Alert on significant movements

### Holding Alerts
- **Dividend Payments** - When dividends are declared
- **Corporate Actions** - Mergers, splits, bonuses
- **News Alerts** - Important company news

## Maintenance Tasks

### Regular Updates

#### Monthly Review
- Check for price updates
- Verify holding accuracy
- Update cost basis if needed
- Review performance

#### Quarterly Tasks
- Tax document preparation
- Performance assessment
- Rebalancing check
- Strategy review

#### Annual Tasks
- Tax filing preparation
- Portfolio audit
- Cost basis verification
- Long-term planning

### Data Backup

#### Export Options
- **CSV Export** - All holdings data
- **PDF Reports** - Formatted portfolio reports
- **API Access** - Programmatic data access
- **Cloud Backup** - Automatic secure backup

## Troubleshooting

### Common Issues

#### Incorrect Values
- **Check Data Entry** - Verify purchase details
- **Update Prices** - Refresh current prices
- **Verify Splits** - Confirm corporate actions
- **Contact Support** - For system issues

#### Missing Transactions
- **Import History** - Check broker statements
- **Manual Entry** - Add missing transactions
- **Reconcile** - Match with broker accounts
- **Documentation** - Keep records of all trades

#### Performance Discrepancies
- **Cost Basis** - Verify purchase prices
- **Dividends** - Include all income
- **Fees** - Account for all costs
- **Timing** - Check transaction dates

## Advanced Features

### Custom Fields
- **Tags and Labels** - Custom categorization
- **Custom Metrics** - Additional calculations
- **Notes and Comments** - Detailed records
- **Attachments** - Link to documents

### Automation
- **Auto-import** - From connected brokers
- **Price Alerts** - Automatic notifications
- **Rebalancing** - Automated adjustments
- **Reporting** - Scheduled reports

## Best Practices

### Record Keeping
1. **Complete Documentation** - Record all transactions
2. **Regular Updates** - Keep portfolio current
3. **Accurate Data** - Verify all information
4. **Backup Regularly** - Secure your data

### Tax Planning
1. **Track Holding Periods** - For tax optimization
2. **Harvest Losses** - Offset gains with losses
3. **Plan Sales** - Time for optimal tax treatment
4. **Maintain Records** - For tax authority requirements

### Performance Focus
1. **Monitor Regularly** - Track progress toward goals
2. **Review Holdings** - Assess ongoing suitability
3. **Rebalance** - Maintain target allocations
4. **Learn Continuously** - Improve investment approach

## Next Steps

Master holding management:

1. **[Understanding Metrics](/portfolio/understanding-metrics)** - Learn portfolio analytics
2. **[Performance Tracking](/portfolio/performance-tracking)** - Monitor your progress
3. **[AI Portfolio Analysis](/portfolio-ai/overview)** - Get AI-powered insights
4. **[Rebalancing Guide](/portfolio-ai/rebalancing)** - Optimize your portfolio

***

**Accurate holding management is crucial for successful investing. Keep detailed, up-to-date records, and you'll have the foundation for informed decision-making.**