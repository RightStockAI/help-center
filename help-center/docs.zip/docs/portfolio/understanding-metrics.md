***
sidebar_position: 3
title: Understanding Portfolio Metrics
description: Learn to interpret portfolio performance metrics and analytics
***

# Understanding Portfolio Metrics

Portfolio metrics help you evaluate performance, assess risk, and make informed decisions. This guide explains key metrics and how to use them effectively.

## Return Metrics

### Total Return
```
Total Return = (Ending Value - Beginning Value + Dividends) / Beginning Value
```

#### Components
- **Capital Appreciation** - Price changes
- **Dividend Income** - Cash payments
- **Reinvested Dividends** - Compounded returns

#### Time Periods
- **1-Day Return** - Yesterday's performance
- **MTD Return** - Month-to-date
- **YTD Return** - Year-to-date
- **1-Year Return** - Annual performance

### Annualized Return
```
Annualized Return = (1 + Total Return)^(1/number of years) - 1
```

#### Benefits
- **Comparability** - Compare different time periods
- **Compounding Effect** - Shows true growth rate
- **Benchmarking** - Compare to market returns

#### Example
- 50% return over 2 years
- Annualized return = (1.50)^(1/2) - 1 = 22.5%

## Risk Metrics

### Volatility (Standard Deviation)
```
Standard Deviation = √[Σ(xi - μ)² / n]
```

#### Interpretation
- **Low Volatility** - Stable, predictable returns
- **High Volatility** - Unstable, unpredictable returns
- **Annualized** - Usually reported as annual figure

#### Portfolio Impact
- **Diversification** - Reduces overall volatility
- **Asset Allocation** - Stocks more volatile than bonds
- **Market Conditions** - Higher in bear markets

### Sharpe Ratio
```
Sharpe Ratio = (Portfolio Return - Risk-Free Rate) / Portfolio Volatility
```

#### Components
- **Excess Return** - Return above risk-free rate
- **Risk** - Portfolio volatility
- **Risk-Free Rate** - Government bond rate

#### Interpretation
- **> 1.0** - Good risk-adjusted returns
- **> 2.0** - Excellent risk-adjusted returns
- **< 0.5** - Poor risk-adjusted returns

### Sortino Ratio
```
Sortino Ratio = (Portfolio Return - Risk-Free Rate) / Downside Deviation
```

#### Advantages over Sharpe
- **Downside Focus** - Only penalizes negative volatility
- **More Relevant** - Investors fear losses more than volatility
- **Better Measure** - For asymmetric return distributions

## Benchmark Comparison

### Benchmark Selection

#### Market Indices
- **NIFTY 50** - Large-cap Indian stocks
- **Sensex** - BSE 30 large-cap stocks
- **NIFTY Midcap** - Mid-cap performance
- **NIFTY Smallcap** - Small-cap performance

#### Customized Benchmarks
- **Peer Group** - Similar investment style
- **Blended Index** - Mix of different indices
- **Custom Index** - Your own benchmark

### Relative Performance

#### Alpha
```
Alpha = Portfolio Return - (Beta × Benchmark Return + Risk-Free Rate)
```

- **Positive Alpha** - Outperforming benchmark
- **Negative Alpha** - Underperforming benchmark
- **Zero Alpha** - Matching benchmark performance

#### Beta
```
Beta = Covariance(Portfolio, Market) / Variance(Market)
```

- **Beta > 1** - More volatile than market
- **Beta < 1** - Less volatile than market
- **Beta = 1** - Matches market volatility

## Portfolio Composition

### Asset Allocation

#### By Security Type
- **Equity** - Stocks and equity funds
- **Debt** - Bonds and fixed income
- **Cash** - Cash equivalents
- **Alternatives** - Gold, real estate, etc.

#### By Market Cap
- **Large Cap** - > ₹20,000 crore market cap
- **Mid Cap** - ₹5,000-20,000 crore
- **Small Cap** - < ₹5,000 crore

#### By Sector
- **IT** - Information technology
- **Banking** - Financial services
- **Energy** - Oil and gas
- **Healthcare** - Medical and pharma

### Diversification Metrics

#### Concentration Risk
- **Top 10 Holdings** - Percentage in largest positions
- **Single Stock Risk** - Largest position percentage
- **Sector Concentration** - Over-exposure to one sector

#### Correlation Analysis
- **Stock Correlation** - How holdings move together
- **Sector Correlation** - Inter-sector relationships
- **Market Correlation** - Portfolio vs market movement

## Performance Attribution

### Return Attribution

#### Security Selection
- **Stock Picking** - Individual stock performance vs benchmark
- **Sector Allocation** - Sector weightings impact
- **Market Timing** - Entry/exit timing impact

#### Factor Attribution
- **Value vs Growth** - Style factor contribution
- **Size Effect** - Large vs small cap impact
- **Quality Factors** - Profitability, leverage effects

### Risk Attribution

#### Risk Decomposition
- **Systematic Risk** - Market-related risk
- **Unsystematic Risk** - Stock-specific risk
- **Factor Risk** - Style and sector risks

#### Contribution Analysis
- **Volatility Contribution** - Each holding's risk impact
- **VaR Contribution** - Value at risk from each position
- **Stress Testing** - Extreme scenario impacts

## Cash Flow Analysis

### Dividend Analysis

#### Dividend Yield
```
Dividend Yield = Annual Dividends / Current Stock Price
```

#### Total Return from Dividends
- **Dividend Income** - Cash received
- **Reinvestment Impact** - Compounded growth
- **Tax Efficiency** - After-tax returns

### Cost Analysis

#### Transaction Costs
- **Brokerage Fees** - Trading commissions
- **Taxes** - Capital gains taxes
- **Opportunity Costs** - Foregone returns

#### Holding Costs
- **Management Fees** - Fund expenses
- **Custody Fees** - Account maintenance
- **Inflation Impact** - Purchasing power erosion

## Time-Weighted vs Money-Weighted Returns

### Time-Weighted Return (TWR)
- **Geometric linking** of sub-period returns
- **Removes timing bias** - Cash flows don't affect
- **Better for performance** - Shows manager skill

### Money-Weighted Return (MWR)
- **Internal Rate of Return** - Considers cash flows
- **Affected by timing** - When money is added/removed
- **Personal relevance** - Shows individual experience

## Rolling Performance

### Rolling Returns
- **1-year rolling** - Annual performance over time
- **3-year rolling** - Multi-year performance trends
- **5-year rolling** - Long-term consistency

### Best/Worst Periods
- **Best Year** - Highest annual return
- **Worst Year** - Lowest annual return
- **Recovery Time** - Time to recover from losses

## Risk-Adjusted Performance

### Value at Risk (VaR)
```
VaR = Expected loss over time period at confidence level
```

#### Confidence Levels
- **95% VaR** - Loss not exceeded 95% of time
- **99% VaR** - Loss not exceeded 99% of time
- **Expected Shortfall** - Average loss beyond VaR

### Maximum Drawdown
```
Maximum Drawdown = (Peak Value - Trough Value) / Peak Value
```

#### Recovery Analysis
- **Drawdown Duration** - Time in drawdown
- **Recovery Time** - Time to new peak
- **Drawdown Frequency** - How often it occurs

## Comparative Analysis

### Peer Comparison

#### Similar Portfolios
- **Risk Profile** - Conservative/moderate/aggressive
- **Investment Style** - Growth, value, blend
- **Asset Allocation** - Stock/bond mix
- **Geographic Focus** - India/global mix

#### Performance Quartiles
- **Top Quartile** - Best 25% performance
- **Median** - Middle performance
- **Bottom Quartile** - Worst 25% performance

### Market Cycle Performance

#### Bull Market Performance
- **Participation** - How much of market gains captured
- **Outperformance** - Excess returns over market
- **Volatility** - Risk during good times

#### Bear Market Performance
- **Loss Magnitude** - How much value lost
- **Recovery Speed** - How quickly recovered
- **Risk Control** - Drawdown management

## Reporting and Visualization

### Dashboard Metrics

#### Key Performance Indicators
- **Total Portfolio Value** - Current worth
- **Day's Change** - Today's performance
- **YTD Return** - Year-to-date performance
- **Benchmark Comparison** - Vs market indices

#### Risk Indicators
- **Portfolio Volatility** - 30-day volatility
- **VaR** - Daily value at risk
- **Beta** - Market sensitivity
- **Sharpe Ratio** - Risk-adjusted returns

### Custom Reports

#### Performance Reports
- **Monthly Summary** - Monthly performance review
- **Quarterly Review** - Comprehensive analysis
- **Annual Report** - Full year assessment
- **Tax Report** - Tax-related information

#### Attribution Reports
- **Return Attribution** - Source of returns
- **Risk Attribution** - Source of risk
- **Holding Analysis** - Individual position review
- **Sector Analysis** - Sector performance breakdown

## Common Pitfalls

### Misinterpreting Metrics

#### Survivorship Bias
- **Only seeing winners** - Failed investments excluded
- **Overestimated returns** - Ignoring closed positions
- **Solution** - Include all historical positions

#### Time Period Bias
- **Cherry picking** - Selecting favorable periods
- **Recency Bias** - Over-weighting recent performance
- **Solution** - Use consistent, long-term periods

### Over-Reliance on Metrics

#### Ignoring Fundamentals
- **Metrics don't tell why** - Need qualitative analysis
- **Past performance ≠ future** - Historical data limitations
- **Solution** - Combine with fundamental research

#### Benchmark Inappropriateness
- **Wrong comparison** - Comparing apples to oranges
- **Style mismatch** - Growth portfolio vs value benchmark
- **Solution** - Choose relevant, appropriate benchmarks

## Advanced Analytics

### Factor Analysis

#### Style Factors
- **Value** - Low P/E, P/B ratios
- **Growth** - High earnings growth
- **Quality** - High profitability, low debt
- **Momentum** - Recent price performance

#### Macro Factors
- **Economic Growth** - GDP, employment
- **Inflation** - Price level changes
- **Interest Rates** - Monetary policy impact
- **Currency** - Exchange rate effects

### Scenario Analysis

#### Stress Testing
- **Market Crash** - 20-50% market decline
- **Interest Rate Shock** - Sudden rate changes
- **Sector Crisis** - Industry-specific problems
- **Geopolitical Events** - Wars, elections impact

#### Monte Carlo Simulation
- **Random Scenarios** - Thousands of market conditions
- **Probability Distribution** - Range of possible outcomes
- **Confidence Intervals** - Best/worst case scenarios

## Best Practices

### Regular Monitoring
1. **Daily Check** - Quick portfolio review
2. **Weekly Analysis** - Performance trends
3. **Monthly Review** - Comprehensive assessment
4. **Quarterly Planning** - Strategy adjustments

### Benchmark Selection
1. **Relevance** - Matches investment style
2. **Accessibility** - Easy to track
3. **Consistency** - Long-term availability
4. **Appropriateness** - Suitable for your goals

### Risk Management
1. **Know your metrics** - Understand what they measure
2. **Set limits** - Maximum acceptable risk levels
3. **Monitor regularly** - Track against limits
4. **Adjust as needed** - Rebalance when necessary

## Next Steps

Master portfolio metrics:

1. **[Performance Tracking](/portfolio/performance-tracking)** - Monitor your progress
2. **[AI Portfolio Analysis](/portfolio-ai/overview)** - Get AI-powered insights
3. **[Rebalancing Guide](/portfolio-ai/rebalancing)** - Optimize your portfolio
4. **[Risk Management](/best-practices/risk-management)** - Protect your capital

***

**Understanding portfolio metrics is essential for successful investing. Use them to evaluate performance, manage risk, and make informed decisions about your portfolio.**