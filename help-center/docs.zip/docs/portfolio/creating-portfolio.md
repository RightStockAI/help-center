***
sidebar_position: 1
title: Creating Your Portfolio
description: Step-by-step guide to setting up your investment portfolio
***

# Creating Your Portfolio

A well-structured portfolio is the foundation of successful investing. This guide walks you through creating and organizing your RightStockAI portfolio to track investments effectively.

## Portfolio Planning

### Define Your Investment Goals

#### Short-term Goals (< 1 year)
- **Emergency Fund** - 3-6 months expenses
- **Major Purchase** - Car, vacation, home down payment
- **Debt Reduction** - Pay off high-interest loans

#### Medium-term Goals (1-5 years)
- **Education** - Children's college fund
- **Home Purchase** - Down payment savings
- **Business Startup** - Seed capital
- **Retirement Boost** - Additional retirement savings

#### Long-term Goals (5+ years)
- **Retirement** - Primary retirement portfolio
- **Wealth Building** - Long-term capital growth
- **Legacy Planning** - Estate building

### Assess Risk Tolerance

#### Conservative Investor
- **Focus** - Capital preservation
- **Volatility Tolerance** - Low (5-10% swings)
- **Time Horizon** - Short to medium-term
- **Asset Mix** - 70% bonds/fixed income, 30% stocks

#### Moderate Investor
- **Focus** - Balanced growth and income
- **Volatility Tolerance** - Medium (10-20% swings)
- **Time Horizon** - Medium to long-term
- **Asset Mix** - 50% stocks, 30% bonds, 20% alternatives

#### Aggressive Investor
- **Focus** - Capital growth
- **Volatility Tolerance** - High (20-30% swings)
- **Time Horizon** - Long-term
- **Asset Mix** - 80% stocks, 20% alternatives

### Determine Investment Horizon

#### Time-Based Horizons
- **Short-term** - < 3 years (focus on stability)
- **Medium-term** - 3-10 years (balanced approach)
- **Long-term** - 10+ years (growth-oriented)

#### Goal-Based Horizons
- **Education** - Match graduation timeline
- **Retirement** - Years until retirement age
- **Major Purchase** - Target completion date

## Creating Your First Portfolio

### Step 1: Access Portfolio Section

1. Log into RightStockAI
2. Click **"Portfolio"** in the main navigation
3. Click **"Create New Portfolio"**
4. Choose portfolio type

### Step 2: Portfolio Setup

#### Basic Information
- **Portfolio Name** - Descriptive name (e.g., "Retirement Portfolio")
- **Description** - Optional details about the portfolio
- **Currency** - Base currency (INR for Indian investors)
- **Start Date** - When you began investing

#### Portfolio Type
- **Individual** - Personal investments
- **Joint** - Shared with spouse/family
- **Trust** - Held in trust
- **Retirement** - Tax-advantaged accounts
- **Education** - 529-type accounts

### Step 3: Set Investment Parameters

#### Risk Settings
- **Risk Tolerance** - Conservative/Moderate/Aggressive
- **Maximum Drawdown** - Acceptable loss percentage
- **Rebalancing Frequency** - How often to rebalance

#### Tax Settings
- **Tax Status** - Individual/HUF/Company
- **Tax Bracket** - Applicable tax rate
- **Long-term Holding** - Minimum holding period for tax benefits

## Adding Holdings

### Manual Entry Method

#### Stock Purchase
1. Click **"Add Holding"**
2. Search for stock symbol or name
3. Select transaction type: **Buy**
4. Enter details:
   - **Date** - Purchase date
   - **Quantity** - Number of shares
   - **Price** - Purchase price per share
   - **Brokerage** - Transaction fees
   - **Exchange Rate** - If applicable

#### Multiple Purchases
- **Average Cost** - System calculates average price
- **Lot Tracking** - Track individual purchase lots
- **Tax Optimization** - FIFO/LIFO cost basis

### Bulk Import Method

#### CSV Import
1. Prepare CSV file with columns:
   - Symbol
   - Date
   - Quantity
   - Price
   - Brokerage
2. Click **"Import Holdings"**
3. Upload CSV file
4. Map columns to RightStockAI fields
5. Review and confirm import

#### Broker Integration
- **Supported Brokers** - Zerodha, Upstox, Angel One
- **API Connection** - Secure broker API integration
- **Auto-sync** - Automatic portfolio updates
- **Transaction History** - Import past trades

## Organizing Your Portfolio

### Portfolio Structure

#### By Investment Type
- **Large Cap** - Blue-chip companies
- **Mid Cap** - Growing companies
- **Small Cap** - High-growth potential
- **Sector Funds** - Sector-specific exposure

#### By Strategy
- **Growth** - High-growth companies
- **Value** - Undervalued companies
- **Dividend** - Income-generating stocks
- **Momentum** - Trending stocks

#### By Time Horizon
- **Short-term** - 0-3 years
- **Medium-term** - 3-7 years
- **Long-term** - 7+ years

### Sub-portfolios

#### Creating Sub-portfolios
1. Within main portfolio, click **"Create Sub-portfolio"**
2. Name the sub-portfolio
3. Set allocation percentage
4. Add holdings to sub-portfolio

#### Benefits
- **Better Organization** - Group related holdings
- **Performance Tracking** - Sub-portfolio level analytics
- **Rebalancing** - Maintain target allocations
- **Tax Planning** - Optimize for different goals

## Setting Up Alerts and Monitoring

### Price Alerts
- **Individual Stock** - Alert at specific prices
- **Portfolio Level** - Alert on portfolio value changes
- **Percentage Changes** - Alert on % movements

### Rebalancing Alerts
- **Drift Alerts** - When allocations deviate from targets
- **Threshold Alerts** - Custom deviation percentages
- **Schedule Alerts** - Regular rebalancing reminders

### Performance Alerts
- **Profit/Loss** - Alert on significant P&L changes
- **Dividend Alerts** - When dividends are paid
- **Corporate Actions** - Mergers, splits, bonuses

## Portfolio Analytics Setup

### Performance Metrics
- **Total Return** - Overall portfolio performance
- **Annualized Return** - Time-weighted returns
- **Benchmark Comparison** - Vs NIFTY 50, Sensex
- **Risk Metrics** - Volatility, Sharpe ratio

### Attribution Analysis
- **Sector Performance** - Which sectors contribute most
- **Stock Performance** - Best/worst performers
- **Timing Impact** - Market timing vs stock selection
- **Cost Analysis** - Impact of fees and commissions

## Tax Optimization

### Tax-Loss Harvesting
- **Identify Losses** - Stocks trading below purchase price
- **Offset Gains** - Use losses to reduce taxable gains
- **Wash Sale Rules** - Avoid repurchasing substantially identical securities
- **Tax Bracket Optimization** - Harvest in higher tax brackets

### Long-term Capital Gains
- **Holding Period** - Benefits after 1 year (India)
- **Indexation** - Adjust cost for inflation
- **Tax Rates** - Lower rates for long-term holdings
- **Planning** - Time holdings for tax efficiency

## Integration with AI Analysis

### Portfolio AI Insights
- **Risk Assessment** - AI-powered portfolio risk analysis
- **Diversification Check** - Optimal asset allocation
- **Rebalancing Suggestions** - AI recommendations
- **Performance Predictions** - Expected portfolio returns

### Individual Stock Analysis
- **AI Predictions** - For current holdings
- **Technical Analysis** - Chart patterns and indicators
- **Correlation Analysis** - How holdings move together
- **Scenario Planning** - Stress testing portfolio

## Best Practices

### Portfolio Construction
1. **Diversification** - Don't put all eggs in one basket
2. **Asset Allocation** - Match risk tolerance and goals
3. **Regular Review** - Monitor and adjust periodically
4. **Cost Control** - Minimize fees and commissions

### Record Keeping
1. **Complete Records** - All transactions documented
2. **Regular Updates** - Keep portfolio current
3. **Backup Data** - Secure storage of records
4. **Tax Preparation** - Organize for tax filing

### Performance Monitoring
1. **Track Progress** - Regular performance reviews
2. **Benchmark Comparison** - Compare to appropriate indices
3. **Risk Assessment** - Monitor portfolio risk
4. **Goal Alignment** - Ensure portfolio matches objectives

## Common Mistakes to Avoid

### Over-concentration
- **Single Stock Risk** - Too much in one company
- **Sector Concentration** - Over-exposure to one industry
- **Geographic Concentration** - All investments in one region

### Poor Record Keeping
- **Missing Transactions** - Incomplete purchase records
- **Incorrect Prices** - Wrong purchase prices entered
- **Missing Fees** - Not including brokerage costs

### Ignoring Rebalancing
- **Drift from Targets** - Allocations change over time
- **Style Drift** - Portfolio changes character
- **Risk Creep** - Risk increases without notice

## Advanced Portfolio Features

### Multi-Asset Portfolios
- **Stocks** - Equity investments
- **Bonds** - Fixed income securities
- **ETFs** - Exchange-traded funds
- **Mutual Funds** - Pooled investment vehicles

### International Exposure
- **Global ETFs** - International market exposure
- **ADRs/GDRs** - Foreign company shares
- **Currency Hedging** - Manage currency risk
- **Emerging Markets** - High-growth potential

### Alternative Investments
- **Gold/Silver** - Precious metals
- **Real Estate** - REITs and property
- **Commodities** - Oil, agriculture, industrial metals
- **Cryptocurrency** - Digital assets (if applicable)

## Getting Help

### Portfolio Support
- **Setup Assistance** - Guided portfolio creation
- **Import Help** - Bulk import support
- **Tax Guidance** - Basic tax optimization tips
- **Performance Analysis** - Understanding metrics

### Resources
- **Portfolio Templates** - Pre-built portfolio structures
- **Educational Content** - Investing basics and advanced topics
- **Community Forums** - User experiences and advice
- **Professional Consultation** - Connect with advisors

## Next Steps

With your portfolio created:

1. **[Managing Holdings](/portfolio/managing-holdings)** - Add and track your investments
2. **[Understanding Metrics](/portfolio/understanding-metrics)** - Learn portfolio analytics
3. **[Performance Tracking](/portfolio/performance-tracking)** - Monitor your progress
4. **[AI Portfolio Analysis](/portfolio-ai/overview)** - Get AI-powered insights

***

**A well-organized portfolio is the foundation of successful investing. Take time to set it up properly, and you'll have a solid base for achieving your financial goals.**