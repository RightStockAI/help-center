---
sidebar_position: 2
---

# Getting Support

Multiple ways to get help when you need it.

## Support Channels

### 📧 Email Support

**support@rightstockai.com**

**Best for:**
- Detailed technical issues
- Account problems
- Feature requests
- Bug reports

**Response Time:**
- Free users: 24-48 hours
- Pro users: 6-12 hours
- Enterprise: 2-4 hours (SLA guaranteed)

**When emailing, include:**
- Clear subject line
- Your account email
- Detailed description
- Screenshots/recordings
- Browser & OS details
- Steps already attempted

---

### 💬 Live Chat

**Available on:** [Support Page](https://www.rightstockai.com/support)

**Hours:** 9:00 AM - 6:00 PM IST (Monday - Friday)

**Best for:**
- Quick questions
- Navigation help
- Feature guidance
- Immediate assistance

**Features:**
- Real-time responses
- Screen sharing available
- Transfer to specialist if needed
- Chat history saved

---

### 📖 Documentation

**You're here!** Browse comprehensive guides:

**Getting Started:**
- [Introduction](../intro)
- [Dashboard Overview](../getting-started/dashboard)
- [Interface Guide](../getting-started/navigation)

**Features:**
- [Stock Analysis](../features/stock-analysis)
- [Traditional Analysis](../features/traditional-analysis)
- [AI Analysis](../features/ai-analysis)
- [Portfolio Management](../features/portfolio-management)

**Help:**
- [FAQ](../faq/account)
- [Troubleshooting](./features)
- [Video Tutorials](#video-tutorials)

---

### 🎯 Interactive Product Tour

**In-App Guided Tour**

Access from:
- Dashboard > Help > Start Tour
- First login (automatic)
- Any page via Help button

**What you'll learn:**
- Platform navigation
- Key features
- Analysis tools
- Portfolio management
- Best practices

[Start Tour](https://www.rightstockai.com/dashboard)

---

### 📱 Social Media

**Stay Connected:**

- **Twitter/X:** @RightStockAI (coming soon)
- **LinkedIn:** RightStockAI (coming soon)
- **YouTube:** Video tutorials (coming soon)

---

## Support Types

### Technical Support

**For issues with:**
- Login/authentication
- Website functionality
- Charts not loading
- Data not updating
- Performance problems
- Browser compatibility

**Contact:** support@rightstockai.com

---

### Billing Support

**For questions about:**
- Subscription plans
- Payment issues
- Invoices
- Refunds
- Plan changes
- Cancellations

**Contact:** billing@rightstockai.com

---

### Feature Questions

**For help with:**
- How to use features
- Understanding analysis
- Portfolio setup
- Interpretation of metrics
- Best practices

**Use:**
- Documentation
- Live chat
- Interactive tour
- Email support

---

### Security Issues

**For concerns about:**
- Account security
- Suspicious activity
- Data privacy
- Unauthorized access

**Contact:** security@rightstockai.com

**Immediate action:**
1. Change password immediately
2. Enable 2FA
3. Check login activity
4. Email security team

---

## Self-Service Resources

### Knowledge Base

**Comprehensive articles on:**
- Account management
- Features and tools
- Analysis methodologies
- Portfolio strategies
- Trading concepts
- Technical indicators
- Market insights

### Video Tutorials

**Coming Soon!**
- Getting started videos
- Feature walkthroughs
- Analysis tutorials
- Portfolio management
- Tips and tricks

### FAQ

[Browse FAQ](../faq/account) for instant answers to:
- Common questions
- Quick solutions
- Feature explanations
- Account issues
- Billing questions

### Troubleshooting Guide

[View Troubleshooting](./features) for:
- Step-by-step solutions
- Error message fixes
- Performance issues
- Data problems
- Browser issues

---

## Enterprise Support

### Dedicated Support

**For Enterprise customers:**
- Dedicated support manager
- Priority response (2-4 hours)
- Phone support
- Video call support
- Custom training sessions
- Onboarding assistance

### SLA Guarantees

**Service Level Agreements:**
- **Critical issues:** 2-hour response
- **High priority:** 4-hour response
- **Normal priority:** 12-hour response
- **Low priority:** 24-hour response

**Uptime Guarantee:**
- 99.9% uptime SLA
- Planned maintenance windows
- Status page access
- Proactive notifications

**Contact:** enterprise@rightstockai.com

---

## Response Time Guidelines

### Free Plan

- **Email:** 24-48 hours
- **Live Chat:** Available but standard priority
- **Documentation:** 24/7 access
- **Product Tour:** Always available

### Pro Plan

- **Email:** 6-12 hours
- **Live Chat:** Priority queue
- **Documentation:** 24/7 access
- **Product Tour:** Always available
- **Follow-up:** Guaranteed

### Enterprise Plan

- **Email:** 2-4 hours (SLA)
- **Phone:** Direct line
- **Live Chat:** Highest priority
- **Video Call:** Available on request
- **Dedicated Manager:** Named contact

---

## Best Practices for Getting Help

### Before Contacting Support

**1. Check Documentation**
- Search this knowledge base
- Read relevant articles
- Watch video tutorials
- Try troubleshooting steps

**2. Try Basic Fixes**
- Refresh page (F5)
- Clear cache (Ctrl + Shift + Delete)
- Try different browser
- Check internet connection
- Log out and back in

**3. Gather Information**
- Note error messages
- Take screenshots
- Record steps to reproduce
- Check browser console (F12)
- Note your browser version

### Writing Effective Support Emails

**Good Support Email Template:**

```
Subject: [Clear, specific issue description]

Account Email: your@email.com
Subscription: Free/Pro
Browser: Chrome 120 (or version)
Operating System: Windows 11/macOS/Linux

Issue Description:
[What were you trying to do?]

What Happened:
[What actually happened? Any error messages?]

Steps to Reproduce:
1. Step one
2. Step two
3. Step three

Already Tried:
- Cleared cache
- Tried different browser
- [Other attempts]

Attachments:
- Screenshot 1
- Screenshot 2
```

### What to Include

**Always Include:**
- Your account email
- Subscription type
- Clear problem description
- Screenshots if applicable

**For Technical Issues:**
- Browser name and version
- Operating system
- Error messages (exact text)
- Console errors (if tech-savvy)

**For Analysis Issues:**
- Stock symbol
- Analysis type
- Date/time of issue
- Expected vs actual result

**For Payment Issues:**
- Transaction ID
- Payment method
- Date of transaction
- Amount charged

---

## Support Priorities

### Critical (P1)

**Examples:**
- Cannot login (widespread)
- Payment processing broken
- Data loss
- Security breach

**Response:** Immediate
**Resolution Target:** 2-4 hours

### High (P2)

**Examples:**
- Feature not working
- Incorrect data
- Subscription issue
- Portfolio not loading

**Response:** 6-12 hours
**Resolution Target:** 24-48 hours

### Normal (P3)

**Examples:**
- Feature questions
- How-to guidance
- Minor bugs
- Enhancement requests

**Response:** 24-48 hours
**Resolution Target:** 3-7 days

### Low (P4)

**Examples:**
- General inquiries
- Feature requests
- Cosmetic issues
- Documentation feedback

**Response:** 48-72 hours
**Resolution Target:** Best effort

---

## Escalation Process

### When to Escalate

Escalate if:
- No response in expected timeframe
- Issue not resolved after multiple attempts
- Critical business impact
- Dissatisfied with resolution

### How to Escalate

1. **Reply to Original Ticket**
   - Reference ticket number
   - Explain escalation reason
   - Request escalation

2. **Email Escalation**
   - escalations@rightstockai.com
   - Include original ticket details
   - Explain urgency

3. **For Enterprise Customers**
   - Contact dedicated support manager
   - Reference SLA agreement
   - Request immediate escalation

---

## Feedback & Suggestions

### We Value Your Input!

**Feature Requests:**
- Email: feedback@rightstockai.com
- Describe feature clearly
- Explain use case
- Share expected benefit

**Bug Reports:**
- Email: bugs@rightstockai.com
- Detailed reproduction steps
- Include screenshots
- Severity assessment

**General Feedback:**
- Email: feedback@rightstockai.com
- Praise, criticism, suggestions
- User experience feedback
- UI/UX improvements

---

## Community (Coming Soon)

### User Forums

**Launching Soon:**
- Community discussions
- User tips and tricks
- Strategy sharing
- Peer support
- Feature discussions

### User Groups

**Connect with others:**
- Regional user groups
- Strategy-specific groups
- Experience level groups
- Industry focus groups

---

## Additional Resources

### Educational Content

**Coming Soon:**
- Webinars
- Workshops
- Trading courses
- Investment guides
- Strategy tutorials

### API Documentation

**For Developers:**
- API reference (coming soon)
- Integration guides
- Code samples
- SDKs and libraries

[API Overview](../api/overview)

---

## Contact Information

### General Support
📧 support@rightstockai.com
💬 [Live Chat](https://www.rightstockai.com/support)

### Billing & Subscriptions
📧 billing@rightstockai.com

### Security Issues
📧 security@rightstockai.com

### Enterprise Sales
📧 enterprise@rightstockai.com

### Partnerships
📧 partnerships@rightstockai.com

### Media Inquiries
📧 media@rightstockai.com

### Feedback & Suggestions
📧 feedback@rightstockai.com

---

## Office Hours

**Live Chat Support:**
Monday - Friday: 9:00 AM - 6:00 PM IST
Saturday: 10:00 AM - 4:00 PM IST
Sunday: Closed

**Email Support:**
Monitored 24/7, responses during business hours

**Emergency Support:**
Enterprise customers: 24/7 on-call available

---

**We're here to help you succeed!** 🚀

Choose the support channel that works best for you, and we'll be happy to assist.