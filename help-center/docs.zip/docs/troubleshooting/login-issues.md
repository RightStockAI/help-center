---
sidebar_position: 3
---

# Login and Authentication Issues

Solutions for common problems accessing your RightStockAI account.

## Login Problems

### Cannot Log In

**Symptoms:** Login page not accepting credentials or showing error messages
**Solutions:**

#### Check Credentials
Verify your login information:
1. **Email Address**: Ensure correct email spelling
2. **Password**: Check for typos and case sensitivity
3. **Account Status**: Verify account is active
4. **Subscription Status**: Check if subscription is expired
5. **Browser Autofill**: May have incorrect saved password

#### Reset Password
If you've forgotten your password:
1. **Click "Forgot Password"**: On login page
2. **Enter Email**: Use your registered email address
3. **Check Email**: Look for reset link in inbox
4. **Check Spam Folder**: Reset email may be filtered
5. **Create New Password**: Follow link instructions
6. **Try Logging In**: Use new password

#### Browser Issues
Resolve browser-specific problems:
1. **Clear Browser Cache**: Remove old login data
2. **Clear Cookies**: Remove stored authentication
3. **Disable Extensions**: Some extensions interfere with login
4. **Try Different Browser**: Chrome, Firefox, Safari, Edge
5. **Update Browser**: Use latest browser version

### Account Locked

**Symptoms:** Account temporarily suspended or locked
**Solutions:**

#### Security Lock
Account locked for security reasons:
1. **Wait for Unlock**: Temporary locks expire automatically
2. **Check Email**: Look for security notification
3. **Verify Identity**: Follow identity verification process
4. **Contact Support**: Request manual unlock
5. **Reset Password**: May resolve security concerns

#### Too Many Failed Attempts
Too many incorrect login attempts:
1. **Wait 30 Minutes**: Lockout period for security
2. **Reset Password**: Use forgot password feature
3. **Check Account Activity**: Review recent login attempts
4. **Enable 2FA**: Add extra security layer
5. **Contact Support**: If lockout persists

### Two-Factor Authentication (2FA) Issues

#### 2FA Not Working
Problems with two-factor authentication:
1. **Check Time**: Ensure device time is correct
2. **Backup Codes**: Use pre-generated backup codes
3. **SMS Issues**: Check phone signal and carrier
4. **App Problems**: Restart authenticator app
5. **Recovery Process**: Use account recovery options

#### Lost 2FA Access
Cannot access 2FA method:
1. **Use Backup Codes**: Enter pre-saved recovery codes
2. **Account Recovery**: Start account recovery process
3. **Contact Support**: Verify identity to reset 2FA
4. **Alternative Methods**: Use different 2FA method if available
5. **Security Questions**: Answer security verification questions

## Session Issues

### Frequent Logout

**Symptoms:** Automatically logged out repeatedly
**Solutions:**

#### Session Timeout
Normal session expiration:
1. **Check Session Length**: Standard timeout may be 30 minutes
2. **Stay Logged In**: Enable "Remember Me" option
3. **Regular Activity**: Use platform to keep session active
4. **Check Security Settings**: High security may timeout faster
5. **Update Browser**: Old browsers may have session issues

#### Connection Issues
Network-related session problems:
1. **Check Internet**: Ensure stable connection
2. **Try Different Network**: Switch WiFi/cellular
3. **Disable VPN**: VPNs may interfere with sessions
4. **Router Restart**: Reset network connection
5. **Contact ISP**: Check for internet service issues

#### Browser Settings
Browser configuration affecting sessions:
1. **Clear Cache**: Remove corrupted session data
2. **Cookie Settings**: Enable cookies for rightstockai.com
3. **Privacy Mode**: Disable private/incognito browsing
4. **Extension Conflicts**: Disable suspicious extensions
5. **Security Software**: Check if antivirus blocks sessions

### Multiple Device Issues

Problems with account on multiple devices:

#### Concurrent Sessions
Account logged in on multiple devices:
1. **Device Limit**: Check maximum allowed devices
2. **Log Out Others**: Sign out from unused devices
3. **Session Management**: Review active sessions in settings
4. **Device Authorization**: Approve new device logins
5. **Security Alerts**: Enable notifications for new logins

#### Device Sync
Synchronization problems between devices:
1. **Manual Sync**: Force synchronization between devices
2. **Check Last Sync**: Verify when data last synchronized
3. **Refresh Data**: Update information on all devices
4. **App Updates**: Ensure all devices have latest version
5. **Contact Support**: Report persistent sync issues

## Account Access Problems

### Account Not Found

**Symptoms:** System says account doesn't exist
**Solutions:**

#### Email Verification
Check if email is registered:
1. **Verify Email**: Confirm correct email address
2. **Check Typos**: Look for spelling mistakes
3. **Try Different Email**: May have used different email
4. **Check Social Login**: If registered with Google/Facebook
5. **Create Account**: May need to register new account

#### Account Status
Account may be inactive or closed:
1. **Check Email**: Look for account status notifications
2. **Reactivate Account**: Follow reactivation instructions
3. **Check Subscription**: Verify account is still active
4. **Contact Support**: Inquire about account status
5. **Create New Account**: If old account cannot be recovered

### Subscription Issues

Problems with account subscription:

#### Expired Subscription
Subscription renewal problems:
1. **Check Expiry Date**: Verify when subscription ended
2. **Renew Subscription**: Update payment method
3. **Check Payment**: Verify payment method is valid
4. **Billing Support**: Contact billing department
5. **Downgrade Plan**: May need to select different plan

#### Payment Failures
Payment processing issues:
1. **Update Payment Method**: Use valid credit card
2. **Check Billing Address**: Verify billing information
3. **Try Different Card**: Use alternative payment method
4. **Contact Bank**: Check if card is blocked for online transactions
5. **PayPal/Other Methods**: Use alternative payment services

## Security Issues

### Suspicious Activity

**Symptoms:** Unrecognized account activity
**Solutions:**

#### Review Account Activity
Check recent account usage:
1. **Login History**: Review recent login times and locations
2. **Device List**: Check authorized devices
3. **Active Sessions**: See current active sessions
4. **API Access**: Review third-party application access
5. **Export Data**: Download account data for review

#### Secure Account
Protect against unauthorized access:
1. **Change Password**: Immediately update password
2. **Enable 2FA**: Add two-factor authentication
3. **Review Permissions**: Revoke unnecessary access
4. **Update Security Questions**: Set new security questions
5. **Contact Support**: Report security concerns

### Account Recovery

Regaining access to compromised account:

#### Immediate Actions
Secure your account quickly:
1. **Change Password**: Prevent further unauthorized access
2. **Enable 2FA**: Add extra security layer
3. **Review Activity**: Check for unauthorized changes
4. **Revoke Sessions**: Log out from all devices
5. **Check Email**: Verify email account hasn't been compromised

#### Recovery Process
Full account recovery steps:
1. **Use Recovery Email**: Access recovery email address
2. **Answer Security Questions**: Verify identity
3. **Provide ID**: Submit identification documents if required
4. **Contact Support**: Work with support team
5. **Set Up New Security**: Establish fresh security measures

## Browser and Device Issues

### Browser Compatibility

Problems with specific browsers:

#### Supported Browsers
Ensure you're using compatible browser:
1. **Chrome**: Version 102 or higher
2. **Firefox**: Version 102 or higher
3. **Safari**: Version 15.4 or higher
4. **Edge**: Version 102 or higher

#### Browser Configuration
Optimize browser settings:
1. **Enable JavaScript**: Required for login functionality
2. **Enable Cookies**: Needed for session management
3. **Disable Pop-up Blockers**: May interfere with login
4. **Clear Cache**: Remove old login data
5. **Update Browser**: Use latest browser version

### Mobile App Issues

Problems with mobile application:

#### App Login
Mobile-specific login problems:
1. **Update App**: Install latest version
2. **Clear App Cache**: Remove corrupted data
3. **Check Internet**: Ensure mobile data connection
4. **Restart Device**: Clear temporary issues
5. **Reinstall App**: Fresh installation if needed

#### Device Compatibility
Ensure device supports app:
1. **Check OS Version**: Verify minimum requirements
2. **Update Operating System**: Install latest OS version
3. **Check Storage**: Ensure sufficient device storage
4. **Check RAM**: Verify sufficient memory
5. **Use Alternative**: Try web version if app fails

## Getting Help

### Self-Service Options
Try these solutions first:

1. **Password Reset**: Use automated password recovery
2. **Account Status**: Check account status page
3. **Help Center**: Browse authentication documentation
4. **FAQ Section**: Review common login questions
5. **Community Forum**: Get help from other users

### Contacting Support
When self-service doesn't work:

#### Support Information
Contact details for authentication issues:
- **Email**: support@rightstockai.com
- **Subject**: "Login Issue - [Your Account Email]"
- **Priority**: Mark as urgent if account access is blocked
- **Response Time**: Typically 2-4 hours for login issues

#### Information to Provide
Help support resolve your issue faster:
1. **Account Email**: Registered email address
2. **Description**: Detailed problem description
3. **Error Messages**: Exact text of any error messages
4. **Steps Taken**: What you've already tried
5. **Browser/Device**: What browser and device you're using

## Prevention Tips

### Security Best Practices
Protect your account:

1. **Strong Password**: Use complex, unique password
2. **Two-Factor Auth**: Enable 2FA for extra security
3. **Regular Updates**: Change password periodically
4. **Secure Email**: Protect email account associated with RightStockAI
5. **Monitor Activity**: Regularly check account activity

### Login Best Practices
Smooth login experience:

1. **Bookmark Login Page**: Save correct URL
2. **Use Official Site**: Avoid phishing sites
3. **Keep Browser Updated**: Use latest browser version
4. **Clear Cache Regularly**: Remove old login data
5. **Save Login Info**: Use browser password manager securely

## Next Steps

- [Getting Help](./getting-help) - Additional support options
- [Feature Troubleshooting](./features) - Platform functionality issues
- [Performance Issues](./performance) - Speed and optimization tips
- [FAQ - Account](../faq/account) - Common account questions

---

**Security Emergency**: If you suspect immediate account compromise, contact security@rightstockai.com immediately