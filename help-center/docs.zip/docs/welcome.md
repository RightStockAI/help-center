***
sidebar_position: 1
title: Welcome to RightStockAI Help Center
description: Everything you need to know about using RightStockAI
***

# Welcome to RightStockAI Help Center 👋

Welcome to the comprehensive help documentation for **RightStockAI** - your AI-powered investment companion for Indian stock markets.

## What is RightStockAI?

RightStockAI is an advanced stock analysis platform that combines:
- **Artificial Intelligence** - Deep learning models that analyze patterns and predict future price movements
- **Traditional Technical Analysis** - Time-tested indicators like RSI, MACD, and Bollinger Bands
- **Portfolio Management** - Track your investments with real-time valuations
- **AI Portfolio Insights** - Get intelligent recommendations for portfolio optimization

## Markets We Cover

- **NSE (National Stock Exchange)**
- **BSE (Bombay Stock Exchange)**
- **NIFTY 50**
- **Sensex**
- Major Indian stocks across all sectors

## Quick Start Guide

New to RightStockAI? Start here:

1. **[Getting Started](/getting-started/introduction)** - Platform overview and basics
2. **[Your First Stock Analysis](/getting-started/first-analysis)** - Analyze your first stock in 5 minutes
3. **[Create Your Portfolio](/portfolio/creating-portfolio)** - Start tracking your investments
4. **[Understanding AI Analysis](/stock-analysis/ai-analysis)** - Learn how our AI works

## Need Help?

- 📚 **Browse Documentation** - Use the sidebar to explore all topics
- 🔍 **Search** - Use the search bar at the top to find specific answers
- 💬 **Contact Support** - Email us at support@rightstockai.com
- 🐛 **Report Issues** - Found a bug? Let us know!

## Key Features

### AI-Powered Analysis
Our machine learning models analyze:
- Historical price patterns and trends
- Volume and market indicators
- Sector correlations and market sentiment
- Technical indicators and momentum

### Traditional Technical Analysis
Access professional-grade indicators:
- Moving Averages (SMA, EMA)
- RSI (Relative Strength Index)
- MACD (Moving Average Convergence Divergence)
- Bollinger Bands
- Support and Resistance Levels

### Portfolio Management
- Track unlimited portfolios
- Real-time portfolio valuations
- Performance metrics and analytics
- Sector allocation breakdowns
- Profit/Loss tracking

### Portfolio AI Insights
- AI-powered risk assessment
- Diversification recommendations
- Rebalancing suggestions
- Performance predictions
- Smart alerts

### Watchlist Management
- Create custom watchlists
- Monitor stocks before investing
- Set price alerts
- Quick analysis access

## Important Disclaimers

:::caution Investment Disclaimer
RightStockAI provides analysis tools and predictions, **not financial advice**.

- Past performance doesn't guarantee future results
- AI predictions are probability-based, not certainties
- Always conduct your own research
- Consider consulting a SEBI-registered financial advisor
- All investments carry risk, including loss of principal
:::

## What's Next?

Choose your path:

- **New User?** → [Getting Started Guide](/getting-started/introduction)
- **Want to analyze stocks?** → [Stock Analysis Overview](/stock-analysis/overview)
- **Need to track investments?** → [Portfolio Management](/portfolio/creating-portfolio)
- **Have questions?** → [FAQ Section](/faq/account)

***

**Last Updated:** December 2025  
**Platform Version:** 2.0

Need immediate help? [Contact Support](mailto:support@rightstockai.com)