***
sidebar_position: 3
title: Watchlist Alerts
description: Set up price and news alerts for watchlist stocks
***

# Watchlist Alerts

Stay informed about important developments in your watchlist stocks with RightStockAI's comprehensive alert system.

## Alert Types

### Price Alerts

#### Target Price Alerts
- **Price Above** - Alert when stock rises above target
- **Price Below** - Alert when stock falls below target
- **Percentage Change** - Alert on % price movements
- **Volume Alerts** - Unusual trading volume

#### Advanced Alerts
- **Technical Alerts** - RSI levels, moving average crosses
- **Range Alerts** - Price entering/exiting ranges
- **Gap Alerts** - Price gaps up or down

### News Alerts

#### Company News
- **Earnings Reports** - Quarterly/annual results
- **Management Changes** - CEO, board changes
- **M&A Activity** - Mergers, acquisitions
- **Regulatory News** - Government actions

#### Market News
- **Sector Developments** - Industry news
- **Economic Data** - GDP, inflation reports
- **Policy Changes** - Government regulations

## Setting Up Alerts

### Individual Stock Alerts
1. Go to stock in watchlist
2. Click "Set Alert"
3. Choose alert type
4. Set parameters
5. Select notification method

### Bulk Alerts
1. Select multiple stocks
2. Choose "Bulk Alerts"
3. Set common parameters
4. Apply to selected stocks

### Watchlist-wide Alerts
1. Edit watchlist settings
2. Set default alerts
3. Apply to all stocks
4. Customize per stock

## Notification Methods

### Email Notifications
- **Immediate Alerts** - Real-time notifications
- **Daily Digest** - Summary of alerts
- **Weekly Summary** - Weekly alert recap
- **Custom Frequency** - User-defined schedules

### Push Notifications
- **Browser Alerts** - Desktop notifications
- **Mobile App** - Smartphone notifications
- **SMS Alerts** - Text message alerts (premium)

### Integration Options
- **Slack/Teams** - Team notifications
- **Webhook** - API integrations
- **Email Forwarding** - Forward to other services

## Alert Management

### Organizing Alerts
- **Priority Levels** - High, medium, low
- **Categories** - Price, news, technical
- **Status** - Active, paused, expired
- **Performance** - Alert trigger history

### Maintenance
- **Review Alerts** - Regular alert audit
- **Update Targets** - Adjust price levels
- **Pause Alerts** - Temporary deactivation
- **Delete Alerts** - Remove inactive alerts

## Best Practices

### Effective Alert Setup
- **Realistic Targets** - Achievable price levels
- **Multiple Methods** - Email + push notifications
- **Priority System** - Focus on important alerts
- **Regular Updates** - Adjust as market changes

### Avoiding Alert Fatigue
- **Limit Alerts** - Not too many notifications
- **Smart Filtering** - Filter out noise
- **Batch Processing** - Group similar alerts
- **Time Windows** - Market hours only

## Next Steps

1. **[Best Practices](/watchlist/best-practices)** - Optimize alert usage