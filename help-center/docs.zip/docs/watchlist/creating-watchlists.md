***
sidebar_position: 1
title: Creating Watchlists
description: Set up and manage custom stock watchlists
***

# Creating Watchlists

Watchlists help you track stocks of interest before investing. Learn how to create, organize, and manage effective watchlists in RightStockAI.

## Watchlist Types

### Strategy-Based Watchlists
- **Growth Stocks** - High-growth potential companies
- **Value Stocks** - Undervalued opportunities
- **Dividend Stocks** - Income-generating companies
- **Momentum Stocks** - Trending securities

### Sector-Based Watchlists
- **Technology** - IT and software companies
- **Banking** - Financial institutions
- **Healthcare** - Medical and pharma companies
- **Energy** - Oil and gas companies

### Custom Watchlists
- **Personal Criteria** - Your own selection rules
- **Research List** - Stocks to analyze
- **Monitoring List** - Current holdings relatives

## Creating a Watchlist

### Step-by-Step Process
1. Navigate to Watchlist section
2. Click "Create New Watchlist"
3. Enter watchlist name and description
4. Set privacy settings
5. Add stocks manually or import

### Watchlist Settings
- **Name** - Descriptive title
- **Description** - Purpose and criteria
- **Privacy** - Public or private
- **Alerts** - Notification preferences

## Adding Stocks

### Manual Addition
1. Use search bar to find stocks
2. Click "Add to Watchlist"
3. Select target watchlist
4. Set price alerts if desired

### Bulk Import
1. Prepare CSV with stock symbols
2. Upload file to watchlist
3. Map columns and import
4. Review and confirm additions

### Screening Tools
- **Fundamental Screens** - P/E, market cap filters
- **Technical Screens** - RSI, moving average filters
- **Custom Criteria** - Build your own filters

## Managing Watchlists

### Organization
- **Folders** - Group related watchlists
- **Tags** - Label watchlists by theme
- **Priority** - High, medium, low importance
- **Schedule** - Review frequency

### Maintenance
- **Regular Updates** - Add/remove stocks
- **Performance Review** - Track watchlist performance
- **Alert Management** - Update price targets
- **Cleanup** - Remove inactive stocks

## Best Practices

### Effective Watchlists
- **Limit Size** - 10-20 stocks per watchlist
- **Clear Criteria** - Defined entry/exit rules
- **Regular Review** - Weekly or monthly updates
- **Goal Alignment** - Match investment objectives

### Common Mistakes
- **Too Many Stocks** - Hard to track effectively
- **No Criteria** - Random stock selection
- **No Review** - Stale watchlists
- **Emotional Decisions** - Fear/greed driven changes

## Next Steps

1. **[Managing Stocks](/watchlist/managing-stocks)** - Track and analyze watchlist stocks
2. **[Alerts](/watchlist/alerts)** - Set up price notifications
3. **[Best Practices](/watchlist/best-practices)** - Optimize watchlist management